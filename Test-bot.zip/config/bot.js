module.exports = {
    emojis: {
        off: ':x:',
        error: ':warning:',
        queue: ':bar_chart:',
        music: ':musical_note:',
        success: '<a:verificado2:752887192379981939>',
    },

    discord: {
        token: 'ODA5MDkzNDc0NTM1MjExMDUw.YCQFBA.XrPDy_3iy0TYZaicucqCL3qe2PE',
        prefix: '-',
        activity: '-play',
    },

    filters: ['8D', 'gate', 'haas', 'phaser', 'treble', 'tremolo', 'vibrato', 'reverse', 'karaoke', 'flanger', 'mcompand', 'pulsator', 'subboost', 'bassboost', 'vaporwave', 'nightcore', 'normalizer', 'surrounding'],
};